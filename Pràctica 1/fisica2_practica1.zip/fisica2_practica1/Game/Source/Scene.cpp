#include "App.h"
#include "Input.h"
#include "Textures.h"
#include "Audio.h"
#include "Render.h"
#include "Window.h"
#include "Scene.h"

#include "Defs.h"
#include "Log.h"

Scene::Scene() : Module()
{
	name.Create("scene");
}

// Destructor
Scene::~Scene()
{}

// Called before render is available
bool Scene::Awake()
{
	LOG("Loading Scene");
	bool ret = true;

	return ret;
}

// Called before the first frame
bool Scene::Start()
{
	img = app->tex->Load("Assets/Textures/test.png");
	planta = app->tex->Load("Assets/Textures/plantas.png");
	tractor = app->tex->Load("Assets/Textures/tractor.png");
	fondo = app->tex->Load("Assets/Textures/fondo.png");
	app->audio->PlayMusic("Assets/Audio/Music/music_spy.ogg");
	return true;
}

// Called each loop iteration
bool Scene::PreUpdate()
{
	return true;
}

// Called each loop iteration
bool Scene::Update(float dt)
{
	if(app->input->GetKey(SDL_SCANCODE_UP) == KEY_REPEAT)
		app->render->camera.y -= 1;

	if(app->input->GetKey(SDL_SCANCODE_DOWN) == KEY_REPEAT)
		app->render->camera.y += 1;

	if(app->input->GetKey(SDL_SCANCODE_LEFT) == KEY_REPEAT)
		app->render->camera.x -= 1;

	if(app->input->GetKey(SDL_SCANCODE_RIGHT) == KEY_REPEAT)
		app->render->camera.x += 1;

	//Get the size of the window
	uint windowW, windowH;
	app->win->GetWindowSize(windowW, windowH);

	//Get the size of the texture
	uint texW, texH;
	app->tex->GetSize(img, texW, texH);

	// Renders the image in the center of the screen
	//app->render->DrawTexture(img, windowW /2 - texW / 2, windowH /2 - texH / 2);




	app->render->DrawRectangle({ (int)posX,260,80,50}, 255, 255, 255, 255);

	if (app->input->GetKey(SDL_SCANCODE_A)) {
		velocidad -= aceleracion * dt;
	}else
	if (app->input->GetKey(SDL_SCANCODE_D)) {
		velocidad += aceleracion * dt;
	}
	else {
		if (velocidad > 0.2) {
			velocidad -= aceleracion * dt;
		}
		else if(velocidad < -0.2) {
			velocidad += aceleracion * dt;
		}
		else {
			velocidad = 0;
		}
	}



	posX += velocidad;
	SDL_Rect planta_rect;
	planta_rect.x = 0;
	planta_rect.y = 0;
	planta_rect.w = 83;
	planta_rect.h = 76;
	
	uint plantW, plantH;
	int plantasX = 150;

	app->tex->GetSize(planta, plantW, plantH);
	int contador = 0;
	int incrContador = 10;
	

	while (contador < 50 * incrContador) {


		if (abs((posX - (plantasX + contador))) < 5 || abs(((posX + 83) - (plantasX + contador))) < 5) {

			if (velocidad > 0) {
				app->render->DrawTexture(planta, plantasX + contador - (plantW / 2), 350 - plantH, &planta_rect, 1, -90);
			}
			else {
				app->render->DrawTexture(planta, plantasX + contador - (plantW / 2), 350 - plantH, &planta_rect, 1, 90);
			}
			
		}
		else if (abs((posX - (plantasX + contador))) < 15 || abs(((posX + 83) - (plantasX + contador))) < 15) {

			if (velocidad > 0) {
				app->render->DrawTexture(planta, plantasX + contador - (plantW / 2), 350 - plantH, &planta_rect, 1, -45);
			}
			else {
				app->render->DrawTexture(planta, plantasX + contador - (plantW / 2), 350 - plantH, &planta_rect, 1, 45);
			}

			
		}
		else {

			app->render->DrawTexture(planta, plantasX + contador - (plantW / 2), 350 - plantH, &planta_rect);
		}






		contador += incrContador;
	}
	


	



	return true;
}

// Called each loop iteration
bool Scene::PostUpdate()
{
	bool ret = true;

	if(app->input->GetKey(SDL_SCANCODE_ESCAPE) == KEY_DOWN)
		ret = false;

	return ret;
}

// Called before quitting
bool Scene::CleanUp()
{
	LOG("Freeing scene");

	return true;
}
