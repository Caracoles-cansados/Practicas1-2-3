# {Project Name}

## Description

{project description}

## Key Features

 - {Feature01}
 - {Feature02}
 - {Feature03}
 - {Feature04}
 
## Controls

 - {ControlsScheme}

## Developers

 - {Dev01} - {Role(s)}
 - {Dev02} - {Role(s)}
 - {Dev03} - {Role(s)}
 - {Dev04} - {Role(s)}

## License

This project is licensed under an unmodified MIT license, which is an OSI-certified license that allows static linking with closed source software. Check [LICENSE](LICENSE) for further details.

{AdditionalLicenses}
